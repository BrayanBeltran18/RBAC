import javax.swing.*;
import java.sql.*;

public class Conexion {

    Connection conectar = null;
    String user = "root";
    String password = "123456";
    String bd = "proyecto";
    String ip = "localhost";
    String port = "3307";

    Statement stm = null;

    String cadena = "jdbc:mysql://"+ip+":"+port+"/"+bd;

    int[] ids;


    public Connection estableceConexion(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena, user, password);
            System.out.println("CONECTADO");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se conecto, error: " + e.toString());
        }
        return conectar;
    }

    public int[] obtenerIds() throws SQLException {
        stm = conectar.createStatement();    //Se crea un statement
        ResultSet rs= stm.executeQuery("SELECT * FROM usuarios");
        int x = 0;
        int y = 0;
        while(rs.next()){
            x++;
        }
        int[] ids = new int[x];
        while(rs.next()){
            x++;
            ids[x] = rs.getInt(1);
        }
        conectar.close();
        return ids;

    }
    public String[] obtenerUser(int id) throws SQLException {
        stm = conectar.createStatement();    //Se crea un statement
        ResultSet rs= stm.executeQuery("SELECT * FROM usuarios WHERE IdUser = " + id);

        String[] datos = new String[2];
        while(rs.next()){
           //datos[0] = rs.getString(2);
           //datos[1] = rs.getString(3);
            System.out.println(rs.getString(2) + "  " + rs.getString(3));
        }
        conectar.close();
        return datos;
    }


}
