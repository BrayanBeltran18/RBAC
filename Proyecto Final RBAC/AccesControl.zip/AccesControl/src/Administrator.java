import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.Serial;
import java.nio.channels.Selector;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class Administrator extends JPanel {
    Color color = new Color(242, 233, 228);

    // versión
    @Serial
    private static final long serialVersionUID = 1L;

    // la tabla
    private JTable table;

    // el modelo de tabla, aquí van a estar los datos.
    private DefaultTableModel model;

    int[] id;
    String[] dat;
    int idU = 1;

    Connection conectar = null;
    String user = "root";
    String password = "123456";
    String bd = "proyecto";
    String ip = "localhost";
    String port = "3307";

    Statement stm = null;
    String cadena = "jdbc:mysql://"+ip+":"+port+"/"+bd;

    JFrame fr;
    JScrollPane adminPane = new JScrollPane();
    JButton addB = new JButton();
    JButton deleteB = new JButton();
    JPanel addP = new JPanel();
    JTextField contr = new JTextField();
    JTextField nombre = new JTextField();
    Choice rol = new Choice();

    JTextPane nombreAgregar = new JTextPane();
    JTextPane contrasenaAgregar = new JTextPane();
    public Administrator(JFrame f, String name) throws SQLException {
        fr =f;

        adminPane.setBounds(50,110,1100,490);
        adminPane.setBackground(color);
        adminPane.setBorder(new RoundedBorder(20));

        fr.add(adminPane);



        // nombre de las columnas
        String[] columnNames = { "ID", "NAME", "ROL" };
        // creo un modelo de datos, sin datos por eso 'null' y establezco los
        // nombres de columna
        model = new DefaultTableModel(null, columnNames);
        // creo la tabla con el modelo de datos creado
        table = new JTable(model);
        table.setBackground(color);
        // se pone la tabla en el scroll
        adminPane.setViewportView(table);
        Conexion objetoConexion = new Conexion();
        objetoConexion.estableceConexion();

        try {
            // creo un vector con una fila
            id = objetoConexion.obtenerIds();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        for (int i = 0; i <= id.length  ; i++) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conectar = DriverManager.getConnection(cadena, user, password);
                System.out.println("CONECTADO");
            }catch (Exception e){
                JOptionPane.showMessageDialog(null, "No se conecto, error: " + e.toString());
            }
            stm = conectar.createStatement();    //Se crea un statement
            ResultSet rs= stm.executeQuery("SELECT * FROM usuarios");

            while (rs.next()){
                for (int t = 0; t < table.getRowCount(); t++) {
                    if ((int)table.getValueAt(t,0) == rs.getInt(1)) {
                        model.removeRow(t);
                    }
                }
                Object[] x = {rs.getInt(1),rs.getString(2),rs.getString(4)  };
                // añado la fila al modelo
                model.addRow(x);
            }

        }




        Image imgExit = new ImageIcon("out/production/Iconos/icons8-delete-user-male-50.png").getImage();
        ImageIcon icExit = new ImageIcon(imgExit.getScaledInstance(49,49, Image.SCALE_SMOOTH));
        deleteB.setIcon(icExit);
        deleteB.setBounds(540,610,50,50);
        deleteB.setBorder(null);
        deleteB.addActionListener(this::button_eliminarActionPerformed);
        deleteB.setBackground(color);
        fr.add(deleteB);


        Image imgAdd = new ImageIcon("out/production/Iconos/icons8-añadir-usuario-masculino-50.png").getImage();
        ImageIcon icAdd = new ImageIcon(imgAdd.getScaledInstance(49,51, Image.SCALE_SMOOTH));
        addB.setIcon(icAdd);
        addB.setBounds(610,610,50,50);
        addB.setBackground(color);
        addB.setBorder(null);
        addB.addActionListener(this::button_addActionPerformed);
        fr.add(addB);
    }
    private void button_eliminarActionPerformed(java.awt.event.ActionEvent evt) {
        int filaSeleccionada;

        try{
            //Guardamos en un entero la fila seleccionada.
            filaSeleccionada = table.getSelectedRow();
            if (filaSeleccionada == -1){
                JOptionPane.showMessageDialog(null, "No ha seleccionado ninguna fila.");
            } else {
                int id = (int) model.getValueAt(filaSeleccionada,0);
                Conexion objetoConexion = new Conexion();
                objetoConexion.estableceConexion();
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    conectar = DriverManager.getConnection(cadena, user, password);
                    System.out.println("CONECTADO");
                }catch (Exception a){
                    JOptionPane.showMessageDialog(null, "No se conecto, error: " + a.toString());
                }
                String s = "DELETE FROM usuarios WHERE IdUser = " + id;
                try {
                    int row = table.getSelectedRow();
                    model.removeRow(row);
                    PreparedStatement st = conectar.prepareStatement(s);
                    st.addBatch();
                    st.executeBatch();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        }catch (HeadlessException ex){
            JOptionPane.showMessageDialog(null, "Error: "+ex+"\nInténtelo nuevamente", " .::Error En la Operacion::." ,JOptionPane.ERROR_MESSAGE);
        }
    }

    private void button_addActionPerformed(java.awt.event.ActionEvent evt) {
        adminPane.setVisible(false);
        addB.setVisible(false);
        deleteB.setVisible(false);
        fr.remove(adminPane);

        addP.setBounds(50,110,1100,490);
        addP.setBackground(color);
        addP.setBorder(new RoundedBorder(20));
        addP.setLayout(null);
        fr.add(addP);


        nombre.setBounds(350,100,200,30);
        nombre.setBackground(color);
        nombre.setBorder(new RoundedBorder(20));
        addP.add(nombre);

        contr.setBounds(350,200,200,30);
        contr.setBackground(color);
        contr.setBorder(new RoundedBorder(20));
        addP.add(contr);

        rol.setBounds(600,150,200,30);
        rol.setBackground(color);
        rol.add("Admin");
        rol.add("Doctor");
        addP.add(rol);

        JButton add = new JButton("CONFIRMAR");
        add.setBackground(color);
        add.setBorder(new RoundedBorder(20));
        add.setBounds(450,400,200,40);
        add.addActionListener(this::button_confirmarActionPerformed);
        addP.add(add);

        nombreAgregar.setText("NOMBRE");
        nombreAgregar.setFont(new Font( "Helvetica", Font.BOLD, 20 ));
        nombreAgregar.setBounds(350,60,200,30);
        nombreAgregar.setBackground(color);
        addP.add(nombreAgregar);

        contrasenaAgregar.setText("CONTRASEÑA");
        contrasenaAgregar.setFont(new Font( "Helvetica", Font.BOLD, 20 ));
        contrasenaAgregar.setBounds(350,160,200,30);
        contrasenaAgregar.setBackground(color);
        addP.add(contrasenaAgregar);
    }
    private void button_confirmarActionPerformed(java.awt.event.ActionEvent evt) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena, user, password);
            System.out.println("CONECTADO");
        }catch (Exception a){
            JOptionPane.showMessageDialog(null, "No se conecto, error: " + a.toString());
        }
        try {
            while (id(idU) == false) {
                idU++;
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        String s = "INSERT INTO usuarios(IdUser, User, Password, Rol) values("+idU+",'"+nombre.getText()+"','"+contr.getText()+"','"+rol.getSelectedItem()+"')";
        try {

            PreparedStatement st = conectar.prepareStatement(s);
            st.addBatch();
            st.executeBatch();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

        addP.setVisible(false);
        fr.remove(addP);
        fr.add(adminPane);
        adminPane.setVisible(true);
        addB.setVisible(true);
        deleteB.setVisible(true);

        Conexion objetoConexion = new Conexion();
        objetoConexion.estableceConexion();
        ResultSet ms;
        try {
            // creo un vector con una fila
            id = objetoConexion.obtenerIds();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        for (int i = 0; i <= id.length  ; i++) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conectar = DriverManager.getConnection(cadena, user, password);
                System.out.println("CONECTADO");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se conecto, error: " + e.toString());
            }
            try {
                stm = conectar.createStatement();
                ms = stm.executeQuery("SELECT * FROM usuarios");//Se crea un statement
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            while (true) {
                try {
                    if (!ms.next()) break;
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                for (int t = 0; t < table.getRowCount(); t++) {
                    try {
                        if ((int) table.getValueAt(t, 0) == ms.getInt(1)) {
                            model.removeRow(t);
                        }
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
                Object[] x = new Object[0];
                try {
                    x = new Object[]{ms.getInt(1), ms.getString(2), ms.getString(4)};
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                // añado la fila al modelo
                model.addRow(x);
            }
        }
    }

    public boolean id(int f) throws SQLException {
        Conexion objetoConexion = null;
        stm = conectar.createStatement();    //Se crea un statement
        ResultSet rs= stm.executeQuery("SELECT * FROM usuarios");

        while (rs.next()){
            if (rs.getInt(1) == f) {
                return false;
            }
        }
        return true;
    }

}