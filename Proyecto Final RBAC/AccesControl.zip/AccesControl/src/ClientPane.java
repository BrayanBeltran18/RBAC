import com.jniwrapper.Str;
import com.toedter.calendar.JCalendar;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.*;
import java.util.Calendar;

import static java.awt.Cursor.HAND_CURSOR;

public class ClientPane extends JPanel implements ActionListener {
    Color color = new Color(242, 233, 228);
    JPanel dPane = new JPanel();
    JPanel dPane_2 = new JPanel();
    JLabel telefonoP = new JLabel();
    JLabel mailP = new JLabel();
    JLabel locationP = new JLabel();
    JButton cdc = new JButton("CAMBIAR DE CITA");
    JButton precio = new JButton("PRECIOS");
    JButton infoContacto = new JButton("INFORMACIÓN DE CONTACTO");
    JButton infoGeneral = new JButton("INFORMACIÓN GENERAL");
    JButton cambioCita = new JButton("Cambiar Cita");

    private JCalendar calendar = new JCalendar();;

    JFrame frame;


    //PANEL CONSULTA DE RESULTADOS.
    JScrollPane avisos;
    DefaultTableModel model;
    JTable table;
    int[] id;
    String[] dat;
    String usu;
    int idd;

    Connection conectar = null;
    String user = "root";
    String password = "123456";
    String bd = "proyecto";
    String ip = "localhost";
    String port = "3307";

    Statement stm = null;
    String cadena = "jdbc:mysql://"+ip+":"+port+"/"+bd;
    JTextPane Con = new JTextPane();
    JTextPane titulo = new JTextPane();
    JTextPane preciosss = new JTextPane();
    JTextPane tituloInfoCont = new JTextPane();
    JTextPane infoCont = new JTextPane ();
    JTextPane personal = new JTextPane();
    JTextPane infoP = new JTextPane();
    JTextPane infoP2 = new JTextPane();

    MouseListener ml=new MouseListener() {

        @Override
        public void mouseClicked(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {
            if (e.getSource() == cdc) {
                cdc.setContentAreaFilled(true);
                cdc.setForeground(Color.WHITE);
                cdc.setBackground(Color.BLACK);
                infoGeneral.setBackground(color);
                infoContacto.setBackground(color);
                precio.setBackground(color);
                cdc.setForeground(Color.WHITE);
                infoGeneral.setForeground(Color.BLACK);
                infoContacto.setForeground(Color.BLACK);
                precio.setForeground(Color.BLACK);
            } else if (e.getSource() == infoGeneral) {
                infoGeneral.setContentAreaFilled(true);
                infoGeneral.setForeground(Color.WHITE);
                cdc.setBackground(color);
                infoGeneral.setBackground(Color.BLACK);
                infoContacto.setBackground(color);
                precio.setBackground(color);
                cdc.setForeground(Color.BLACK);
                infoGeneral.setForeground(Color.WHITE);
                infoContacto.setForeground(Color.BLACK);
                precio.setForeground(Color.BLACK);
            } else if (e.getSource() == infoContacto) {
                infoContacto.setContentAreaFilled(true);
                infoContacto.setForeground(Color.WHITE);
                cdc.setBackground(color);
                infoGeneral.setBackground(color);
                infoContacto.setBackground(Color.BLACK);
                precio.setBackground(color);
                cdc.setForeground(Color.BLACK);
                infoGeneral.setForeground(Color.BLACK);
                infoContacto.setForeground(Color.WHITE);
                precio.setForeground(Color.BLACK);
            } else if (e.getSource() == precio) {
                precio.setContentAreaFilled(true);
                precio.setForeground(Color.WHITE);
                cdc.setBackground(color);
                infoGeneral.setBackground(color);
                infoContacto.setBackground(color);
                precio.setBackground(Color.BLACK);
                cdc.setForeground(Color.BLACK);
                infoGeneral.setForeground(Color.BLACK);
                infoContacto.setForeground(Color.BLACK);
                precio.setForeground(Color.WHITE);
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {
            if (e.getSource() == cdc) {
                dPane.removeAll();
                dPane.setVisible(false);
                dPane.setVisible(true);
                cdc.setContentAreaFilled(false);

                //Calendario
                calendar.setBounds(new Rectangle(50, 30, 700, 390));
                calendar.setTodayButtonVisible(true);
                dPane.add(calendar);

                //Boton de cambio de cita
                cambioCita.setBorder(new RoundedBorder(25));
                cambioCita.setFont(new Font( "Helvetica", Font.BOLD, 19 ));
                dPane.add(cambioCita);
            } else if (e.getSource() == infoGeneral) {
                dPane.removeAll();
                dPane.setVisible(false);
                dPane.setVisible(true);
                //dPane.setVisible(false);
                infoGeneral.setContentAreaFilled(false);

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    conectar = DriverManager.getConnection(cadena, user, password);
                    System.out.println("CONECTADO");
                }catch (Exception a){
                    JOptionPane.showMessageDialog(null, "No se conecto, error: " + a.toString());
                }

                texto(personal,250,50,300,50,"INFORMACION PERSONAL");
                texto(infoP,60, 130,310,300,"Nombre:\n\nNumero:\n\nEdad:\n\nGenero:\n\nAlergias:");
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    conectar = DriverManager.getConnection(cadena, user, password);
                    System.out.println("CONECTADO");
                }catch (Exception a){
                    JOptionPane.showMessageDialog(null, "No se conecto, error: " + a.toString());
                }
                try {
                    stm = conectar.createStatement();
                    ResultSet rs= stm.executeQuery("SELECT * FROM pacientes");//Se crea un statement
                    while (rs.next()){
                        if (rs.getString(2).equals(usu)) {
                            String alerg = rs.getString(9);
                            int edad = rs.getInt(8);
                            int number = rs.getInt(11);
                            String genero = rs.getString(7);
                            texto(infoP2,370,130,310,300,""+usu+" "+rs.getString(3)+" "+rs.getString(4)+"\n\n"+number+"\n\n"+edad+"\n\n"+genero+"\n\n"+alerg);
                        }
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                
            } else if (e.getSource() == infoContacto) {
                dPane.removeAll();
                dPane.setVisible(false);
                dPane.setVisible(true);
                infoContacto.setContentAreaFilled(false);
                texto(tituloInfoCont, 250,30,400,50,"INFORMACIÓN DE CONTACTO");
                tituloInfoCont.setFont(new Font( "Helvetica", Font.BOLD, 24 ));
                texto(infoCont,125,130,300,300,"NÚMEROS DE TELEFONO\n6381-28-59-93\n6624-02-58-26\n\nCORREO ELECTRÓNICO\nconsultoriomédico@DSI2.com\n\nDIRECCIÓN\nBlvd. Luis Encinas J, Calle Av. Rosales &, Centro, 83000 Hermosillo, Son.");
                telefonoP.setBackground(color);
                telefonoP.setBounds(600,120,99,99);
                dPane.add(telefonoP);
                Image telefono = new ImageIcon("out/production/Iconos/telephone.png").getImage();
                ImageIcon telefonoI = new ImageIcon(telefono.getScaledInstance(99,99,Image.SCALE_SMOOTH));
                telefonoP.setIcon(telefonoI);
                dPane.add(telefonoP);

                mailP.setBackground(color);
                mailP.setBounds(590,220,99,99);
                dPane.add(mailP);
                Image mail = new ImageIcon("out/production/Iconos/mail.png").getImage();
                ImageIcon mailI = new ImageIcon(mail.getScaledInstance(99,99,Image.SCALE_SMOOTH));
                mailP.setIcon(mailI);
                dPane.add(mailP);

                locationP.setBackground(color);
                locationP.setBounds(600,320,99,99);
                dPane.add(locationP);
                Image location = new ImageIcon("out/production/Iconos/location.png").getImage();
                ImageIcon locationI = new ImageIcon(location.getScaledInstance(99,99,Image.SCALE_SMOOTH));
                locationP.setIcon(locationI);
                dPane.add(locationP);

            } else if (e.getSource() == precio) {
                dPane.removeAll();
                dPane.setVisible(false);
                dPane.setVisible(true);
                precio.setContentAreaFilled(false);
                texto(Con,125, 130,300,300,"Consulta Médica\nCertificado Médico\nAplicación de Inyección\nCuraciones\nSutura\nNebulizaciones\nToma de Presión Arterial\nExtracción de Uña Enterrada");
                texto(titulo, 300,30,300,50,"SERVICIOS Y PRECIOS");
                titulo.setFont(new Font( "Helvetica", Font.BOLD, 24 ));
                texto(preciosss,625,130,100,300,"$50\n$50\n$20\n$50\n$100\n$50\n$15\n$100");

            } else if (e.getSource() == cambioCita) {

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    conectar = DriverManager.getConnection(cadena, user, password);
                    System.out.println("CONECTADO");
                }catch (Exception a){
                    JOptionPane.showMessageDialog(null, "No se conecto, error: " + a.toString());
                }
                int año = calendar.getCalendar().get(Calendar.YEAR);
                int mes = calendar.getCalendar().get(Calendar.MARCH);
                int dia = calendar.getCalendar().get(Calendar.DAY_OF_MONTH);
                String s = "UPDATE `proyecto`.`usuarios` SET `Cita` = '"+año+"-"+mes+"-"+dia+"' WHERE (`IdUser` = '"+idd+"');";
                String s2 = "UPDATE `proyecto`.`pacientes` SET `Cita` = '"+año+"-"+mes+"-"+dia+"' WHERE (`idPacientes` = '"+idd+"');";
                try {
                    PreparedStatement st = conectar.prepareStatement(s);
                    st.addBatch();
                    st.executeBatch();

                    PreparedStatement st2 = conectar.prepareStatement(s2);
                    st2.addBatch();
                    st2.executeBatch();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        }

        @Override
        public void mouseExited(MouseEvent e) {
            if (e.getSource() == cdc) {
                cdc.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
            } else if (e.getSource() == infoGeneral) {
                infoGeneral.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
            } else if (e.getSource() == infoContacto) {
                infoContacto.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
            } else if (e.getSource() == precio) {
                precio.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
            }
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            if (e.getSource() == cdc) {
                cdc.setFont(new Font( "Helvetica", Font.BOLD, 22 ) );
            } else if (e.getSource() == infoGeneral) {
                infoGeneral.setFont(new Font( "Helvetica", Font.BOLD, 22 ) );
            } else if (e.getSource() == infoContacto) {
                infoContacto.setFont(new Font( "Helvetica", Font.BOLD, 22 ) );
            } else if (e.getSource() == precio) {
                precio.setFont(new Font( "Helvetica", Font.BOLD, 22 ) );
            }
        }
    };
    public ClientPane(JFrame panel, String usuario, int id){
        calendar.setBounds(new Rectangle(275, 225, 250, 240));
        idd = id;
        usu = usuario;
        frame = panel;
        dPane.setBounds(348, 110, 800, 490);
        dPane.setBackground(color);
        dPane.setBorder(new RoundedBorder(10));
        dPane.setLayout(null);
        panel.add(dPane);

        dPane_2.setBounds(50, 110, 300, 490);
        dPane_2.setBackground(color);
        dPane_2.setBorder(null);
        dPane_2.setLayout(null);
        panel.add(dPane_2);

        boton(infoGeneral, 0,0,300,122);
        boton(infoContacto, 0,122,300,122);
        boton(precio, 0,244,300,122);
        boton(cdc, 0,366,300,124);
        boton(cambioCita,275,435,250,40);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cdc) {
            cdc.setBackground(Color.BLACK);
            infoGeneral.setBackground(color);
            infoContacto.setBackground(color);
            precio.setBackground(color);
            cdc.setForeground(Color.WHITE);
            infoGeneral.setForeground(Color.BLACK);
            infoContacto.setForeground(Color.BLACK);
            precio.setForeground(Color.BLACK);

        } else if (e.getSource() == infoGeneral) {
            cdc.setBackground(color);
            infoGeneral.setBackground(Color.BLACK);
            infoContacto.setBackground(color);
            precio.setBackground(color);
            cdc.setForeground(Color.BLACK);
            infoGeneral.setForeground(Color.WHITE);
            infoContacto.setForeground(Color.BLACK);
            precio.setForeground(Color.BLACK);
        } else if (e.getSource() == infoContacto) {
            cdc.setBackground(color);
            infoGeneral.setBackground(color);
            infoContacto.setBackground(Color.BLACK);
            precio.setBackground(color);
            cdc.setForeground(Color.BLACK);
            infoGeneral.setForeground(Color.BLACK);
            infoContacto.setForeground(Color.WHITE);
            precio.setForeground(Color.BLACK);
        } else if (e.getSource() == precio) {
            cdc.setBackground(color);
            infoGeneral.setBackground(color);
            infoContacto.setBackground(color);
            precio.setBackground(Color.BLACK);
            cdc.setForeground(Color.BLACK);
            infoGeneral.setForeground(Color.BLACK);
            infoContacto.setForeground(Color.BLACK);
            precio.setForeground(Color.WHITE);
        }
    }

    public void boton(JButton b, int x, int y, int width,int height){
        b.setContentAreaFilled(false);
        b.setBorder(null);
        b.setBackground(color);
        b.setBounds(x,y,width,height);
        b.setFont(new Font( "Helvetica", Font.BOLD, 18 ));
        b.addMouseListener(ml);
        b.setCursor(new Cursor(HAND_CURSOR));
        dPane_2.add(b);
    }
    public void texto(JTextPane tP, int x, int y, int width, int height, String name ){
        tP.setText(name);
        tP.setBorder(null);
        tP.setBounds(x,y,width,height);
        tP.setFont(new Font( "Helvetica", Font.BOLD, 20 ));
        tP.setBackground(color);
        tP.setEditable(false);
        dPane.add(tP);
    }

}
/*avisos = new JScrollPane();
        //avisos.setBounds(348, 110, 800, 490);
        avisos.setSize(100,100);
        String[] columnNames = { "ID" };
        model = new DefaultTableModel(null, columnNames);
        table = new JTable(model);
        table.setBackground(color);
        avisos.setViewportView(table);
        for (int i = 0; i < 100; i++) {

        // creo un vector con una fila
        Object[] aux = { i };

        // añado la fila al modelo
        model.addRow(aux);
        }
        dPane.add(avisos);*/