import com.toedter.calendar.JCalendar;


import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.PanelUI;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;
import javax.swing.plaf.nimbus.NimbusStyle;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.Serial;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static java.awt.Cursor.HAND_CURSOR;

public class DoctorPane extends JPanel {
    Color color = new Color(242, 233, 228);

    JPanel dPane = new JPanel();
    JScrollPane dPane_2 = new JScrollPane();

    @Serial
    private static final long serialVersionUID = 1L;
    private JTable table;

    // el modelo de tabla, aquí van a estar los datos.
    private DefaultTableModel model;

    DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    private JCalendar calendar;
    //Formulario
    JTextField nombreB = new JTextField();
    JTextField cuales_B = new JTextField();
    JTextField edad_B = new JTextField();
    JTextField apellidoP_B = new JTextField();
    JTextField apellidoM_B = new JTextField();
    JTextField num_B = new JTextField();
    JTextField correo_B = new JTextField();
    int idU = 1;

    JButton aggB = new JButton("Agregar Paciente");
    int[] id;

    Choice Lista;
    Choice Lista2;
    Connection conectar = null;
    String user = "root";
    String password = "123456";
    String bd = "proyecto";
    String ip = "localhost";
    String port = "3307";

    Statement stm = null;
    String cadena = "jdbc:mysql://"+ip+":"+port+"/"+bd;



    public DoctorPane (JFrame dp) throws SQLException {

        dPane.setBounds(350, 110, 800, 490);
        dPane.setBackground(color);
        dPane.setBorder(new RoundedBorder(20));
        dPane.setLayout(null);
        dp.add(dPane);

        dPane_2.setBounds(50, 110, 300, 490);
        dPane_2.setBackground(color);
        dPane_2.setBorder(new RoundedBorder(20));
        dp.add(dPane_2);

        String[] columnNames = {"DATE", "NAME"};
        model = new DefaultTableModel(null, columnNames) {
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        };
        ;
        table = new JTable(model);
        table.setBackground(color);
        table.setModel(model);
        dPane_2.setViewportView(table);
        listar();
        table.getColumnModel().getColumn(0).setCellRenderer(new TimestampCellRenderer() );
        //Registro del Doc

        nombreB.setLayout(null);
        nombreB.setBounds(new Rectangle(10, 50, 250, 40));
        nombreB.setBackground(new Color(242, 233, 228));
        nombreB.setBorder(new RoundedBorder(20));
        nombreB.setFont(new Font("Helvetica", Font.BOLD, 15));
        nombreB.setAlignmentY(TOP_ALIGNMENT);
        dPane.add(nombreB);


        apellidoP_B.setLayout(null);
        apellidoP_B.setBounds(new Rectangle(275, 50, 250, 40));
        apellidoP_B.setBackground(new Color(242, 233, 228));
        apellidoP_B.setBorder(new RoundedBorder(20));
        apellidoP_B.setFont(new Font("Helvetica", Font.BOLD, 14));
        apellidoP_B.setAlignmentY(TOP_ALIGNMENT);
        dPane.add(apellidoP_B);


        apellidoM_B.setLayout(null);
        apellidoM_B.setBounds(new Rectangle(540, 50, 250, 40));
        apellidoM_B.setBackground(new Color(242, 233, 228));
        apellidoM_B.setBorder(new RoundedBorder(20));
        apellidoM_B.setFont(new Font("Helvetica", Font.BOLD, 15));
        apellidoM_B.setAlignmentY(TOP_ALIGNMENT);
        dPane.add(apellidoM_B);


        num_B.setLayout(null);
        num_B.setBounds(new Rectangle(10, 140, 250, 40));
        num_B.setBackground(new Color(242, 233, 228));
        num_B.setBorder(new RoundedBorder(20));
        num_B.setFont(new Font("Helvetica", Font.BOLD, 15));
        num_B.setAlignmentY(TOP_ALIGNMENT);
        dPane.add(num_B);


        correo_B.setLayout(null);
        correo_B.setBounds(new Rectangle(275, 140, 250, 40));
        correo_B.setBackground(new Color(242, 233, 228));
        correo_B.setBorder(new RoundedBorder(20));
        correo_B.setFont(new Font("Helvetica", Font.BOLD, 15));
        correo_B.setAlignmentY(TOP_ALIGNMENT);
        dPane.add(correo_B);


        edad_B.setLayout(null);
        edad_B.setBounds(new Rectangle(10, 225, 250, 40));
        edad_B.setBackground(new Color(242, 233, 228));
        edad_B.setBorder(new RoundedBorder(20));
        edad_B.setFont(new Font("Helvetica", Font.BOLD, 15));
        edad_B.setAlignmentY(TOP_ALIGNMENT);
        dPane.add(edad_B);


        cuales_B.setLayout(null);
        cuales_B.setBounds(new Rectangle(10, 385, 250, 40));
        cuales_B.setBackground(new Color(242, 233, 228));
        cuales_B.setBorder(new RoundedBorder(20));
        cuales_B.setFont(new Font("Helvetica", Font.BOLD, 15));
        cuales_B.setAlignmentY(TOP_ALIGNMENT);
        dPane.add(cuales_B);

        JTextPane nombreT = new JTextPane();
        nombreT.setLayout(null);
        nombreT.setBounds(new Rectangle(10, 15, 250, 30));
        nombreT.setBackground(new Color(242, 233, 228));
        nombreT.setFont(new Font("Helvetica", Font.BOLD, 17));
        nombreT.setAlignmentY(TOP_ALIGNMENT);
        nombreT.setText("Nombre(s)");
        nombreT.setEditable(false);
        dPane.add(nombreT);

        JTextPane apellidoP = new JTextPane();
        apellidoP.setLayout(null);
        apellidoP.setBounds(new Rectangle(275, 15, 250, 30));
        apellidoP.setBackground(new Color(242, 233, 228));
        apellidoP.setFont(new Font("Helvetica", Font.BOLD, 17));
        apellidoP.setAlignmentY(TOP_ALIGNMENT);
        apellidoP.setText("Apellido Paterno");
        apellidoP.setEditable(false);
        dPane.add(apellidoP);

        JTextPane apellidoM = new JTextPane();
        apellidoM.setLayout(null);
        apellidoM.setBounds(new Rectangle(540, 15, 250, 30));
        apellidoM.setBackground(new Color(242, 233, 228));
        apellidoM.setFont(new Font("Helvetica", Font.BOLD, 17));
        apellidoM.setAlignmentY(TOP_ALIGNMENT);
        apellidoM.setText("Apellido Materno");
        apellidoM.setEditable(false);
        dPane.add(apellidoM);

        JTextPane num = new JTextPane();
        num.setLayout(null);
        num.setBounds(new Rectangle(10, 100, 250, 30));
        num.setBackground(new Color(242, 233, 228));
        num.setFont(new Font("Helvetica", Font.BOLD, 17));
        num.setAlignmentY(TOP_ALIGNMENT);
        num.setText("Número de Telefono");
        num.setEditable(false);
        dPane.add(num);

        JTextPane correo = new JTextPane();
        correo.setLayout(null);
        correo.setBounds(new Rectangle(275, 100, 250, 30));
        correo.setBackground(new Color(242, 233, 228));
        correo.setFont(new Font("Helvetica", Font.BOLD, 17));
        correo.setAlignmentY(TOP_ALIGNMENT);
        correo.setText("Correo Electrónico");
        correo.setEditable(false);
        dPane.add(correo);

        JTextPane genero = new JTextPane();
        genero.setLayout(null);
        genero.setBounds(new Rectangle(540, 100, 250, 30));
        genero.setBackground(new Color(242, 233, 228));
        genero.setFont(new Font("Helvetica", Font.BOLD, 17));
        genero.setAlignmentY(TOP_ALIGNMENT);
        genero.setText("Género");
        genero.setEditable(false);
        dPane.add(genero);

        JTextPane edad = new JTextPane();
        edad.setLayout(null);
        edad.setBounds(new Rectangle(10, 190, 250, 30));
        edad.setBackground(new Color(242, 233, 228));
        edad.setFont(new Font("Helvetica", Font.BOLD, 17));
        edad.setAlignmentY(TOP_ALIGNMENT);
        edad.setText("Edad");
        edad.setEditable(false);
        dPane.add(edad);

        JTextPane calendario = new JTextPane();
        calendario.setLayout(null);
        calendario.setBounds(new Rectangle(275, 190, 250, 30));
        calendario.setBackground(new Color(242, 233, 228));
        calendario.setFont(new Font("Helvetica", Font.BOLD, 17));
        calendario.setAlignmentY(TOP_ALIGNMENT);
        calendario.setText("Próxima Cita");
        calendario.setEditable(false);
        dPane.add(calendario);

        JTextPane alergias = new JTextPane();
        alergias.setLayout(null);
        alergias.setBounds(new Rectangle(10, 280, 250, 30));
        alergias.setBackground(new Color(242, 233, 228));
        alergias.setFont(new Font("Helvetica", Font.BOLD, 17));
        alergias.setAlignmentY(TOP_ALIGNMENT);
        alergias.setText("Alergias");
        alergias.setEditable(false);
        dPane.add(alergias);

        JTextPane cuales = new JTextPane();
        cuales.setLayout(null);
        cuales.setBounds(new Rectangle(10, 350, 250, 30));
        cuales.setBackground(new Color(242, 233, 228));
        cuales.setFont(new Font("Helvetica", Font.BOLD, 17));
        cuales.setAlignmentY(TOP_ALIGNMENT);
        cuales.setText("¿Cuáles?");
        cuales.setEditable(false);
        dPane.add(cuales);

        aggB.setBounds(580,300,150,50);
        //aggB.addActionListener(this::button_comprarActionPerformed);
        aggB.addMouseListener(ml);
        //aggB.setBounds(new Rectangle(540, 15, 250, 30));
        aggB.setBorder(new RoundedBorder(25));
        aggB.setBackground(color);
        aggB.setCursor(new Cursor(HAND_CURSOR));
        dPane.add(aggB);

        Lista = new Choice();
        Lista.setCursor(new Cursor(HAND_CURSOR));
        Lista.setBounds(new Rectangle(540, 145, 250, 30));
        Lista.setName("Genero");
        Lista.setBackground(new Color(242, 233, 228));
        Lista.setFont(new Font("Helvetica", Font.BOLD, 17));
        Lista.addItem("Selecciona un Género");
        Lista.addItem( "Hombre" );
        Lista.addItem( "Mujer" );
        dPane.add(Lista);

        Lista2 = new Choice();
        Lista2.setCursor(new Cursor(HAND_CURSOR));
        Lista2.setBounds(new Rectangle(10, 310, 250, 40));
        Lista2.setName("Alergias");
        Lista2.setBackground(new Color(242, 233, 228));
        Lista2.setFont(new Font("Helvetica", Font.BOLD, 17));
        Lista2.addItem( "Si" );
        Lista2.addItem( "No" );
        dPane.add(Lista2);

        calendar = new JCalendar();

        // Ubicar y agregar al panel
        calendar.setBounds(new Rectangle(275, 225, 250, 240));
        calendar.setTodayButtonVisible(true);
        dPane.add(calendar);
    }
    MouseListener ml = new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {
            Conexion objetoConexion = new Conexion();
            objetoConexion.estableceConexion();
            int año = calendar.getCalendar().get(Calendar.YEAR);
            int mes = calendar.getCalendar().get(Calendar.MARCH);
            int dia = calendar.getCalendar().get(Calendar.DAY_OF_MONTH);
            int gen = 0;
            if (Lista.getSelectedItem().equals("Si")) {
                gen = 1;
            }else{
                gen = 0;
            }
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conectar = DriverManager.getConnection(cadena, user, password);
                System.out.println("CONECTADO");
            }catch (Exception a){
                JOptionPane.showMessageDialog(null, "No se conecto, error: " + a.toString());
            }
            try {
                while (id(idU) == false) {
                    idU++;
                }
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
            String s = "INSERT INTO usuarios(IdUser, User, Password, Rol, Cita) values("+idU+",'"+nombreB.getText()+"','','Paciente','"+año+"-"+mes+"-"+dia+"')";
            String s2 = "INSERT INTO Pacientes(idPacientes, Nombre, ApellidoPaterno, ApellidoMaterno, Alergias, Genero, Edad, NombreAlergias, Cita, Number) values("+idU+",'"+nombreB.getText()+"','"+apellidoP_B.getText()+"','"+apellidoM_B.getText()+"','"+gen+"','"+Lista.getSelectedItem()+"','"+edad_B.getText()+"','"+cuales_B.getText()+"','"+año+"-"+mes+"-"+dia+"','"+num_B.getText()+"')";
            try {

                PreparedStatement st = conectar.prepareStatement(s);
                st.addBatch();
                st.executeBatch();

                PreparedStatement st2 = conectar.prepareStatement(s2);
                st2.addBatch();
                st2.executeBatch();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
            try {
                listar();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {
            aggB.setBounds(560,270,200,100);
            aggB.setFont(new Font("Helvetica", Font.BOLD, 16));
            aggB.setBorder(new RoundedBorder(30));

        }

        @Override
        public void mouseExited(MouseEvent e) {
            aggB.setBounds(580,300,150,50);
            aggB.setFont(new Font("Helvetica", Font.BOLD, 12));
            aggB.setForeground(Color.BLACK);
            aggB.setBackground(color);
            aggB.setBorder(new RoundedBorder(25));
        }
    };
    public boolean id(int f) throws SQLException {
        Conexion objetoConexion = null;
        stm = conectar.createStatement();    //Se crea un statement
        ResultSet rs= stm.executeQuery("SELECT * FROM usuarios");

        while (rs.next()){
            if (rs.getInt(1) == f) {
                return false;
            }
        }
        return true;
    }
    public void listar() throws SQLException {
        Conexion objetoConexion = new Conexion();
        objetoConexion.estableceConexion();

        try {
            //OBTIENE LOS ID EN UNA LISTA
            id = objetoConexion.obtenerIds();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        //ITERAR LA TABLA

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena, user, password);
            System.out.println("CONECTADO_DOCTOR");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se conecto, error: " + e.toString());
        }
        stm = conectar.createStatement();    //Se crea un statement
        ResultSet rs= stm.executeQuery("SELECT * FROM usuarios");
        limpiartabla();
        while (rs.next()){

            if (rs.getString(4).equals("Paciente")) {
                Object[] x = {rs.getDate(5), rs.getString(2) };
                // añado la fila al modelo
                model.addRow(x);
            }

        }


    }
    void limpiartabla() {

        int a = model.getRowCount() - 1;
        System.out.println(a);
        for (int i = a; i >= 0; i--) {
            System.out.println(i);
            model.removeRow(i);
        }
    }
    // Instanciar Componente

    }

