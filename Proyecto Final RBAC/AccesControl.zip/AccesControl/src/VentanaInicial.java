import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.RoundRectangle2D;
import java.security.Key;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;


public class VentanaInicial extends JFrame implements ActionListener, KeyListener {
    //color fondo
    Color color = new Color(242, 233, 228);
    Color colorF = new Color(34, 34, 59);

    JButton iconExit = new JButton();
    JPanel icUser = new JPanel();
    JPanel info = new JPanel();
    JPanel exit = new JPanel();
    JLabel ic1 = new JLabel();
    JTextField user = new JTextField();
    JPasswordField password = new JPasswordField();
    JTextPane userName = new JTextPane();
    JTextPane rolPanel = new JTextPane();

    Object[] usuarios;

    int id;
    String us;
    String rol;

    Connection conectar = null;
    String userQ = "root";
    String passwordQ = "123456";
    String bd = "proyecto";
    String ip = "localhost";
    String port = "3307";
    Statement stm = null;
    String cadena = "jdbc:mysql://"+ip+":"+port+"/"+bd;

    public VentanaInicial(){


        //Posicion y tamano de ventana
        this.setBounds(0, 0, 1200, 700);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        //this.add(colorFondo);
        this.setUndecorated(true);
        this.getContentPane().setBackground(color);
        Shape forma = new RoundRectangle2D.Double(0, 0, this.getBounds().width, this.getBounds().height, 70, 70);
        this.setShape(forma);

        //Acciones de ventana
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);


        //Iconos
        icUser.setBackground(color);
        icUser.setBounds(555,175,90,90);
        //icUser.setBorder(new LineBorder(Color.blue));
        this.add(icUser);
        Image img= new ImageIcon("out/production/Iconos/icons8-usuario-90.png").getImage();
        ImageIcon img2=new ImageIcon(img.getScaledInstance(99, 99, Image.SCALE_SMOOTH));
        ic1.setIcon(img2);
        icUser.add(ic1);

        //Boton Salir
        exit.setBackground(color);
        exit.setBounds(40,620,50,50);
        exit.setCursor(new Cursor(HAND_CURSOR));
        iconExit.setBackground(color);
        Image imgExit = new ImageIcon("out/production/Iconos/icons8-salir-redondeado-50.png").getImage();
        ImageIcon icExit = new ImageIcon(imgExit.getScaledInstance(49,49, Image.SCALE_SMOOTH));
        iconExit.setIcon(icExit);
        iconExit.setBorder(null);
        exit.add(iconExit);
        this.add(exit);
        iconExit.addActionListener(this);

        //TextBox
        info.setBackground(color);
        info.setBounds(450,300,300,350);

        //info.setBorder(new LineBorder(Color.blue));
        info.setLayout(null);

        //Text
        JTextPane tUser = new JTextPane();
        tUser.setBackground(color);
        tUser.setBounds(new Rectangle(25, 5, 250, 35));
        tUser.setText("User");
        tUser.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
        tUser.setForeground(colorF);
        tUser.setEditable(false);
        info.add(tUser);

        JTextPane tPassword = new JTextPane();
        tPassword.setBackground(color);
        tPassword.setBounds(new Rectangle(25, 95, 250, 35));
        tPassword.setText("Password");
        tPassword.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
        tPassword.setForeground(colorF);
        tPassword.setEditable(false);
        info.add(tPassword);


        //Botones
        user.setBounds(new Rectangle(25, 40, 250, 38));
        user.setBackground(color);
        user.setBorder(new RoundedBorder(20));
        user.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
        user.setForeground(colorF);
        user.addKeyListener(this);


        password.setBounds(new Rectangle(25, 130, 250, 38));
        password.setBackground(color);
        password.setBorder(new RoundedBorder(20));
        password.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
        password.setForeground(colorF);
        password.addKeyListener(this);
        info.add(user);
        info.add(password);
        this.add(info);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == iconExit) {
            System.exit(0);
        }
    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent arg0) {
        if (arg0.getKeyCode() == KeyEvent.VK_ENTER)System.out.println("He presionado enter");

        if (arg0.getKeyCode() == KeyEvent.VK_ENTER) {

            us = user.getText();
            Conexion objetoConexion = new Conexion();
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conectar = DriverManager.getConnection(cadena, userQ, passwordQ);
                System.out.println("CONECTADO");

                if(userBool(us) == false){
                    user.setForeground(Color.RED);
                }else{
                    if (rol.equals("Admin")) {
                        newPosition();
                        try {
                            Administrator ad =  new Administrator(this, us);
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                    } else if (rol.equals("Doctor")) {
                        newPosition();
                        DoctorPane dp = new DoctorPane(this);
                    } else if (rol.equals("Paciente")) {
                        newPosition();
                        ClientPane cp = new ClientPane(this, us,id);
                    }
                }
            }catch (Exception a){
                JOptionPane.showMessageDialog(null, "No se conecto, error: " + a.toString());
            }
        }
    }
    public boolean userBool(String  u) throws SQLException {
        Conexion objetoConexion = null;
        stm = conectar.createStatement();    //Se crea un statement
        ResultSet rs= stm.executeQuery("SELECT * FROM usuarios");

        while (rs.next()){
            if (rs.getString(2).equals(u)) {
                rol = rs.getString(4);
                id = rs.getInt(1);
                System.out.println("ENCONTRADO");
                return true;
            }
        }
        return false;
    }
    public void newPosition(){
        info.setVisible(false);
        this.remove(info);


        exit.setBounds(1100,40,50,50);
        icUser.setBounds(50,40,50,50);
        Image img= new ImageIcon("out/production/Iconos/icons8-usuario-90.png").getImage();
        ImageIcon img2=new ImageIcon(img.getScaledInstance(49, 49, Image.SCALE_SMOOTH));
        ic1.setIcon(img2);

        userName.setBackground(color);
        userName.setBounds(new Rectangle(110, 40, 250, 25));
        userName.setText(us);
        userName.setFont(new Font( "Helvetica", Font.BOLD, 18 ) );
        userName.setForeground(colorF);
        userName.setEditable(false);
        this.add(userName);

        rolPanel.setBackground(color);
        rolPanel.setBounds(new Rectangle(110, 65, 250, 25));
        rolPanel.setText(rol);
        rolPanel.setFont(new Font( "Helvetica", Font.ITALIC, 18 ) );
        rolPanel.setForeground(colorF);
        rolPanel.setEditable(false);
        this.add(rolPanel);
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}