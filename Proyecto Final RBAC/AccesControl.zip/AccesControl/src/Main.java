import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame VentanaInicial = new VentanaInicial();
        VentanaInicial.setVisible(true);

        Conexion objetoConexion = new Conexion();
        objetoConexion.estableceConexion();
    }
}